# Support Tools

Practice repository for CIS-1160 Git activities.

This repository contains simple technical support documentation used to practise version control.

## Purpose

These files support a repeatable network troubleshooting process.
